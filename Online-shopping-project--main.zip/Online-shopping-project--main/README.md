# Online-shopping-project-
Project for predicting  profit  using online shopping dataseti
